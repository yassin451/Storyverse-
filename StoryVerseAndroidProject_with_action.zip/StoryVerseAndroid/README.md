StoryVerse Android v1
======================
مشروع Android كامل لنسخة StoryVerse التجريبية.

البناء:
1. افتح المجلد StoryVerseAndroid في Android Studio.
2. انتظر Gradle Sync.
3. اختر Build > Build APK(s).
4. ستجد APK داخل app/build/outputs/apk/debug/.

متطلبات:
- Android Studio حديث يدعم Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK 35.

هذه النسخة تجريبية وتحتوي على واجهات محلية فقط؛ لا يوجد Backend أو تسجيل دخول أو إعلانات أو دفع حتى الآن.
