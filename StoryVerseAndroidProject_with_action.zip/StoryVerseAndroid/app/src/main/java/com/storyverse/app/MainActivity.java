package com.storyverse.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    int purple=Color.rgb(115,92,255), bg=Color.rgb(7,11,24), card=Color.rgb(16,23,43), white=Color.rgb(246,247,255), muted=Color.rgb(170,178,204);
    String[][] stories={{"مملكة الظلال","خيال","🏰"},{"البيت المسكون","رعب","👻"},{"لغز الجريمة","غموض","🕵️"},{"بيننا","رومانسي","❤️"}};

    public void onCreate(Bundle b){super.onCreate(b); showHome();}

    TextView tv(String s,float size,int color){
        TextView v=new TextView(this); v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        v.setPadding(18,12,18,12); return v;
    }
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(white);b.setTextSize(14);b.setBackground(bg(purple,28));return b;}

    void base(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=tv("StoryVerse",25,white);logo.setTypeface(null,1);
        bar.addView(logo,new LinearLayout.LayoutParams(0,70,1));
        TextView bell=tv("🔔",22,white);bar.addView(bell,new LinearLayout.LayoutParams(60,70));
        root.addView(bar);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setBackgroundColor(Color.rgb(11,17,36));
        String[] ns={"⌂\nالرئيسية","▦\nالتصنيفات","♡\nالمفضلة","⌕\nالبحث","♙\nحسابي"};
        for(int i=0;i<5;i++){Button n=new Button(this);n.setText(ns[i]);n.setTextColor(white);n.setTextSize(11);final int x=i;n.setOnClickListener(v->{if(x==0)showHome();else if(x==1)showCategories();else if(x==2)showFavorites();else if(x==3)showSearch();else showProfile();});nav.addView(n,new LinearLayout.LayoutParams(0,76,1));}
        root.addView(nav);setContentView(root);
    }

    void showHome(){
        base("الرئيسية");content.addView(tv("مرحبًا بك 👋",25,white));content.addView(tv("اكتشف قصصًا جديدة وعِش مغامرات لا تنتهي.",15,muted));
        TextView hero=tv("قصة مميزة\n\nمملكة الظلال\nمغامرة غامضة تبدأ في قرية صغيرة وتفتح بابًا لعالم آخر.",20,white);hero.setBackground(bg(Color.rgb(39,31,80),30));hero.setPadding(22,22,22,22);hero.setOnClickListener(v->reader(0));content.addView(hero,new LinearLayout.LayoutParams(-1,220){ {setMargins(18,15,18,15);} });
        content.addView(tv("الأكثر قراءة 🔥",19,white));
        for(int i=0;i<stories.length;i++) addStory(i);
    }
    void addStory(int i){
        LinearLayout r=new LinearLayout(this);r.setPadding(12,12,12,12);r.setBackground(bg(card,24));
        TextView cover=tv(stories[i][2],35,white);cover.setGravity(Gravity.CENTER);r.addView(cover,new LinearLayout.LayoutParams(100,100));
        TextView info=tv(stories[i][0]+"\n"+stories[i][1],18,white);r.addView(info,new LinearLayout.LayoutParams(0,100,1));
        r.setOnClickListener(v->reader(i));content.addView(r,new LinearLayout.LayoutParams(-1,120){ {setMargins(18,7,18,7);} });
    }
    void reader(int i){
        base("قراءة");content.addView(tv("‹",32,white));content.addView(tv(stories[i][0],27,white));content.addView(tv("بواسطة كاتب StoryVerse · "+stories[i][1],14,muted));
        content.addView(tv("كانت السماء هادئة، لكن شيئًا غريبًا كان على وشك أن يبدأ. سار البطل في الطريق المظلم وهو يحمل في يده رسالة قديمة لا يعرف مصدرها.\n\nكل خطوة كانت تقوده إلى سر جديد، ومع كل صفحة تبدأ حكاية مختلفة...\n\nتابع القراءة لاكتشاف ما سيحدث في الفصل التالي.",19,white));
        Button f=btn("♡ أضف للمفضلة");content.addView(f,new LinearLayout.LayoutParams(-1,60){ {setMargins(18,20,18,10);} });
        Button n=btn("الفصل التالي");content.addView(n,new LinearLayout.LayoutParams(-1,60){ {setMargins(18,5,18,10);} });
    }
    void showCategories(){base("التصنيفات");content.addView(tv("التصنيفات",26,white));String[] c={"👻 رعب","🕵️ غموض","🧙 خيال","⚔️ مغامرات","❤️ رومانسي","😂 كوميدي"};for(String x:c){TextView t=tv(x,20,white);t.setBackground(bg(card,22));content.addView(t,new LinearLayout.LayoutParams(-1,90){ {setMargins(18,7,18,7);} });}}
    void showFavorites(){base("المفضلة");content.addView(tv("المفضلة 💙",26,white));content.addView(tv("لم تضف أي قصة للمفضلة بعد.",16,muted));}
    void showSearch(){base("البحث");content.addView(tv("البحث",26,white));EditText e=new EditText(this);e.setHint("ابحث عن قصة أو مؤلف...");e.setTextColor(white);e.setHintTextColor(muted);e.setBackground(bg(card,20));content.addView(e,new LinearLayout.LayoutParams(-1,65){ {setMargins(18,5,18,20);} });for(int i=0;i<stories.length;i++)addStory(i);}
    void showProfile(){base("حسابي");TextView p=tv("📖\n\nقارئ StoryVerse\n\nاستمتع بقراءة قصصك المفضلة",22,white);p.setGravity(Gravity.CENTER);content.addView(p,new LinearLayout.LayoutParams(-1,250));content.addView(tv("⚙️   الإعدادات",18,white));content.addView(tv("🔔   الإشعارات",18,white));}
}